package com.example.clientserver;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

public class Server {

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(8000); // Create server socket
        System.out.println("Server started at " + new Date() + '\n');
        Socket socket = serverSocket.accept(); // start listening for connections
        DataInputStream inputFromClient = new DataInputStream(socket.getInputStream());
        DataOutputStream outputToClient = new DataOutputStream(socket.getOutputStream());

        while (true) {
            try {
                double num = inputFromClient.readDouble();
                double area = num * num * Math.PI;
                outputToClient.writeDouble(area);
                System.out.println("Number received from client: " + num + '\n');
                System.out.println("Result found: " + area + '\n');
            } catch (Exception ex) {
            }
        }
    }

}

