package com.example.clientserver;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class Client implements Initializable {

    private DataInputStream fromServer;
    private DataOutputStream toServer;

    @FXML
    private TextField textField;

    @FXML
    private TextArea textArea;

    // Method to handle button action
    @FXML
    private void buttonAction() throws IOException {
        radiusTFAction();
    }

    private void radiusTFAction() throws IOException {
        try {
            double radius = Double.parseDouble(textField.getText().trim());
            toServer.writeDouble(radius);
            toServer.flush();
            double area = fromServer.readDouble();
            textArea.appendText("Radius is: " + radius + '\n');
            textArea.appendText("Area from server: " + area + '\n');
            textField.clear();
        } catch (IOException e) {
            textArea.appendText("Error: " + e.getMessage() + '\n');
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            Socket socket = new Socket("localhost", 8000);
            fromServer = new DataInputStream(socket.getInputStream());
            toServer = new DataOutputStream(socket.getOutputStream());
        } catch (IOException e) {
            textArea.appendText("Error connecting to server: " + e.getMessage() + '\n');
        }
    }
}