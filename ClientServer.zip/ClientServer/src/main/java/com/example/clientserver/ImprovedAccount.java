package com.example.clientserver;

public class ImprovedAccount extends Account{
    // Create a new lock
    private static final Lock lock = new ReentrantLock();

    // Create a condition
    private static final Condition newDeposit = lock.newCondition();

    public void withdraw(int amount) {
        lock.lock(); // Acquire the lock
        try {
            while (balance < amount) {
                System.out.println("Wait for a deposit");
                newDeposit.await();
            }
            balance -= amount;
            System.out.println("Withdraw " + amount +" Current Balance: " + getBalance());
        }
        catch (InterruptedException ex) {
            System.out.println("Interrupted exception");
        }
        finally {
            lock.unlock(); // Release the lock
        }
    }

    @Override
    public void deposit(int amount) {
        lock.lock();
        try {
            balance += amount;
            System.out.println("Deposit " + amount +" Current Balance: "+ getBalance());

            // Signal thread waiting on the condition
            newDeposit.signalAll();
        }
        finally {
            lock.unlock();
        }
    }
}
