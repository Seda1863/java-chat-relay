package com.example.clientserver;

public class Account {
    protected int balance = 0;
    public int getBalance() {
        return balance;
    }

    public void deposit(int amount) {
        //lock
        int x;
        x= balance+amount;
        balance = x;
        //unlock
    }
}
