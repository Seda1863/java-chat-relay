/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loancalculator;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
public class LoancalculatorController implements Initializable {

    @FXML
    private TextField tfAnnualInterestRate;
    @FXML
    private TextField tfNumberOfYears;
    @FXML
    private TextField tfLoanAmount;
    @FXML
    private TextField tfMonthlyPayment;
    @FXML
    private TextField tfTotalPayment;
    @FXML
    private Button calButton;


    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    @FXML
    private void calculateBtnClick(ActionEvent event) {
        double interest = Double.parseDouble(tfAnnualInterestRate.getText());
        int year = Integer.parseInt(tfNumberOfYears.getText());
        double loanAmount = Double.parseDouble(tfLoanAmount.getText());


        Loan loan = new Loan(interest, year, loanAmount);
        double payment = loan.getMonthlyPayment();
        double totalPayment = loan.getTotalPayment();

        tfMonthlyPayment.setText(loan.getMonthlyPayment()+"");//to covert double to string add ""
        tfTotalPayment.setText(loan.getTotalPayment()+"");
    }

    @FXML
    private void textolayim(ActionEvent event) {
        tfNumberOfYears.setText(tfAnnualInterestRate.getText());
    }

}
