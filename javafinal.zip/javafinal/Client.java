package com.example.ff;

public class Client implements Runnable {
    private final int[] rowData;
    private int sum;

    public Client(int[] rowData) {
        this.rowData = rowData;
        this.sum = 0;
    }

    @Override
    public void run() {
        // Calculate the sum of the row
        for (int num : rowData) {
            sum += num;
        }
    }

    public int getResult() {
        return sum;
    }
}