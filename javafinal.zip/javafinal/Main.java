package com.example.ff;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        int[][] array = {
                {1, 2, 3},
                {4, 5, 6},
                {7, 8, 9}
        };

        Server server = new Server(array);

        int[] rowSums = server.calculateRowSums();

        System.out.println("Sum of each row: " + Arrays.toString(rowSums));
    }
}