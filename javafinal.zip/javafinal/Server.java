package com.example.ff;
import java.util.Arrays;
public class Server {
    private final int[][] array;
    private final List<Client> clients;

    public Server(int[][] array) {
        this.array = array;
        this.clients = new ArrayList<>();
    }

    public int[] calculateRowSums() {
        int numRows = array.length;
        int[] rowSums = new int[numRows];
        Thread[] threads = new Thread[numRows];

        for (int i = 0; i < numRows; i++) {
            Client client = new Client(array[i]);
            clients.add(client);
            threads[i] = new Thread(client);
            threads[i].start();
        }

        for (int i = 0; i < numRows; i++) {
            try {
                threads[i].join();
                rowSums[i] = clients.get(i).getResult();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        return rowSums;
    }
}