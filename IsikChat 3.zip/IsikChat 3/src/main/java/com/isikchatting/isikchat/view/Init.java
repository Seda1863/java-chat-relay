package com.isikchatting.isikchat.view;

public class Init {
    // to make it view package openable for fxml
}
