package com.isikchatting.server.enums;

public enum RoomType {
    PRIVATE,
    GROUP,
}
