package com.isikchatting.server.enums;

public enum RoomStatus {
    ON_REQUEST,
    ACTIVE,
}
